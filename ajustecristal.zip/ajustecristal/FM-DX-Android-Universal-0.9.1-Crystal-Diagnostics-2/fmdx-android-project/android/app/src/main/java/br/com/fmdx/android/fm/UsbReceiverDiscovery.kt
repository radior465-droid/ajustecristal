package br.com.fmdx.android.fm

import android.content.Context
import android.hardware.usb.UsbManager

/** Lista periféricos USB conectados. Identificar um USB não significa que ele seja um tuner FM/SDR. */
class UsbReceiverDiscovery(context: Context) {
    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    fun describeAttachedDevices(): List<String> = usbManager.deviceList.values.map { device ->
        "${device.deviceName}: VID=%04X PID=%04X, interfaces=%d".format(
            device.vendorId, device.productId, device.interfaceCount
        )
    }
}
