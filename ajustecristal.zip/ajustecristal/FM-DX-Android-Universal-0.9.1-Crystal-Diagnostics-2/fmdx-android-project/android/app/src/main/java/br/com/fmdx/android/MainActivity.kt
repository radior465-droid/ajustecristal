package br.com.fmdx.android

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import br.com.fmdx.android.fm.FmHardwareManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // O endereço pode ser configurado na tela inicial e fica salvo no aparelho.
    private val DEFAULT_DIRECTORY_API = ""
    private val prefs by lazy { getSharedPreferences("fmdx", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var web: WebView? = null
    private val bg = Color.rgb(8, 21, 34)
    private val panel = Color.rgb(19, 43, 64)
    private val cyan = Color.rgb(53, 182, 232)
    private val white = Color.WHITE
    private val fmHardwareManager by lazy { FmHardwareManager(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 18); setBackgroundColor(bg) }
        val heading = TextView(this).apply { text = title; textSize = 25f; setTextColor(white); setPadding(0, 4, 0, 6); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(heading)
        status = TextView(this).apply { text = "FM-DX • Rádio definida por software"; textSize = 13f; setTextColor(0xFF9EB8CC.toInt()); setPadding(0, 0, 0, 18) }
        root.addView(status)
        return root
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        setOnClickListener { action() }
    }

    private fun addField(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); setHintTextColor(0xFF8EA7BA.toInt()); setTextColor(white)
        textSize = 15f; setSingleLine(true); setPadding(14, 8, 14, 8)
        backgroundTintList = android.content.res.ColorStateList.valueOf(cyan)
    }

    private fun showHome() {
        web = null
        val layout = base("FM-DX Android")
        val subtitle = TextView(this).apply { text = "Sua porta de entrada para servidores FM-DX"; setTextColor(white); textSize = 16f }
        layout.addView(subtitle)
        val url = addField("Endereço do servidor (https://...)")
        layout.addView(url, matchWrap())
        val directory = addField("API do diretório (ex.: https://meuservidor.com/api)", prefs.getString("directory_api", DEFAULT_DIRECTORY_API) ?: DEFAULT_DIRECTORY_API)
        layout.addView(directory, matchWrap())
        layout.addView(button("SALVAR API DO DIRETÓRIO") {
            val api = normalizeApi(directory.text.toString())
            if (api == null) toast("Informe uma API http:// ou https:// válida")
            else { prefs.edit().putString("directory_api", api).apply(); toast("API do diretório salva") }
        }, matchWrap())
        layout.addView(button("CONECTAR AO SERVIDOR") {
            val address = normalize(url.text.toString())
            if (address == null) toast("Digite um endereço http:// ou https:// válido") else openServer(address)
        }, matchWrap())
        layout.addView(button("SERVIDORES PÚBLICOS") { loadDirectory(layout) }, matchWrap())
        layout.addView(button("MEU RECEPTOR FM") { showFmReceiver() }, matchWrap())
        layout.addView(button("DIAGNÓSTICO UNIVERSAL") { showUniversalDiagnostics() }, matchWrap())
        layout.addView(button("DIAGNÓSTICO SAMSUNG / EXYNOS") { showSamsungDiagnostics() }, matchWrap())
        layout.addView(button("INTERFACE DO CRISTAL / OSCILADOR") { showCrystalDiagnostics() }, matchWrap())
        layout.addView(button("MEUS SERVIDORES / CONVITES") { showSaved(layout) }, matchWrap())
        layout.addView(button("ADICIONAR AOS MEUS SERVIDORES") {
            val address = normalize(url.text.toString())
            if (address == null) toast("Informe um endereço válido") else { saveServer(address); toast("Endereço salvo") }
        }, matchWrap())
        val note = TextView(this).apply {
            text = "Dica: servidores privados não aparecem na lista pública. Use o endereço ou convite enviado pelo proprietário. O servidor FM-DX e o receptor precisam estar ligados."
            setTextColor(0xFF9EB8CC.toInt()); textSize = 13f; setPadding(0, 22, 0, 0)
        }
        layout.addView(note)
        setContentView(layout)
    }


    private fun showUniversalDiagnostics() {
        web = null
        val layout = base("Diagnóstico Universal")
        val report = TextView(this).apply {
            text = fmHardwareManager.universalDiagnosticReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR DIAGNÓSTICO") { showUniversalDiagnostics() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showCrystalDiagnostics() {
        web = null
        val layout = base("Interface do Cristal / Oscilador")
        val report = TextView(this).apply {
            text = br.com.fmdx.android.fm.CrystalInterfaceDiagnostics().run().asText()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR DIAGNÓSTICO") { showCrystalDiagnostics() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showSamsungDiagnostics() {
        web = null
        val layout = base("Diagnóstico Samsung / Exynos")
        val report = TextView(this).apply {
            text = fmHardwareManager.samsungDiagnosticReport()
            textSize = 14f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        val scroll = ScrollView(this)
        scroll.addView(report)
        layout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(button("ATUALIZAR DIAGNÓSTICO") { showSamsungDiagnostics() }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun showFmReceiver() {
        web = null
        val layout = base("Meu Receptor FM")
        val info = TextView(this).apply {
            text = fmHardwareManager.report()
            textSize = 16f
            setTextColor(white)
            setPadding(0, 18, 0, 18)
        }
        layout.addView(info)
        val controller = fmHardwareManager.controller()
        val freq = addField("Frequência em MHz (ex.: 96.1)")
        layout.addView(freq, matchWrap())
        layout.addView(button("INICIAR RECEPTOR") {
            if (!controller.isSupported()) toast("Hardware FM ainda não suportado neste aparelho")
            else toast(if (controller.start()) "Receptor iniciado" else "Não foi possível iniciar o receptor")
        }, matchWrap())
        layout.addView(button("SINTONIZAR") {
            val mhz = freq.text.toString().trim().replace(',', '.').toDoubleOrNull()
            if (mhz == null) toast("Digite uma frequência válida")
            else if (!controller.tune((mhz * 1000).toInt())) toast("Sintonia não disponível neste backend")
            else toast("Sintonizado")
        }, matchWrap())
        layout.addView(button("SEEK ↑") {
            val found = controller.seekUp()
            if (found == null) toast("Busca automática não disponível neste backend") else { freq.setText(found / 1000.0); toast("Nova frequência encontrada") }
        }, matchWrap())
        layout.addView(button("SEEK ↓") {
            val found = controller.seekDown()
            if (found == null) toast("Busca automática não disponível neste backend") else { freq.setText(found / 1000.0); toast("Nova frequência encontrada") }
        }, matchWrap())
        layout.addView(button("PARAR RECEPTOR") { controller.stop(); toast("Receptor parado") }, matchWrap())
        layout.addView(button("← VOLTAR") { showHome() }, matchWrap())
        setContentView(layout)
    }

    private fun loadDirectory(layout: LinearLayout) {
        val directoryApi = prefs.getString("directory_api", DEFAULT_DIRECTORY_API)?.trim().orEmpty()
        if (directoryApi.isBlank()) { toast("Configure a API do diretório na tela inicial"); return }
        status.text = "Buscando servidores..."
        thread {
            try {
                val conn = (URL("$directoryApi/servers").openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
                val data = conn.inputStream.bufferedReader().use { it.readText() }; conn.disconnect()
                val arr = JSONArray(data)
                runOnUiThread {
                    layout.removeViews(3, (layout.childCount - 3).coerceAtLeast(0))
                    val label = TextView(this).apply { text = "SERVIDORES ENCONTRADOS: ${arr.length()}"; setTextColor(cyan); textSize = 15f; setPadding(0, 16, 0, 8) }
                    layout.addView(label)
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i); val name = item.optString("name", "Servidor FM-DX")
                        val info = listOf(item.optString("city"), item.optString("country")).filter { it.isNotBlank() }.joinToString(" • ")
                        layout.addView(button("$name\n$info") { openServer(item.getString("url")) }, matchWrap())
                    }
                    status.text = "Diretório público atualizado"
                }
            } catch (e: Exception) { runOnUiThread { status.text = "Não foi possível acessar o diretório"; toast(e.message ?: "Erro de conexão") } }
        }
    }

    private fun showSaved(layout: LinearLayout) {
        val arr = JSONArray(prefs.getString("servers", "[]"))
        layout.addView(TextView(this).apply { text = "SERVIDORES SALVOS"; setTextColor(cyan); textSize = 15f; setPadding(0, 14, 0, 8) })
        for (i in 0 until arr.length()) {
            val address = arr.optString(i)
            layout.addView(button(address) { openServer(address) }, matchWrap())
        }
        if (arr.length() == 0) toast("Nenhum servidor salvo ainda")
    }

    private fun saveServer(address: String) {
        val old = JSONArray(prefs.getString("servers", "[]")); val next = JSONArray()
        for (i in 0 until old.length()) if (old.optString(i) != address) next.put(old.optString(i))
        next.put(address); prefs.edit().putString("servers", next.toString()).apply()
    }

    private fun openServer(address: String) {
        val view = WebView(this)
        web = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.webChromeClient = WebChromeClient()
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { status.text = "Conectado: ${url ?: address}" }
        }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        shell.addView(button("← VOLTAR À LISTA") { view.stopLoading(); showHome() }, matchWrap())
        shell.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(shell)
        view.loadUrl(address)
    }

    private fun normalizeApi(raw: String): String? {
        val value = normalize(raw) ?: return null
        return if (value.endsWith("/api")) value else "$value/api"
    }

    private fun normalize(raw: String): String? {
        val value = raw.trim().trimEnd('/')
        if (!value.startsWith("https://") && !value.startsWith("http://")) return null
        return try { val u = URL(value); if (u.host.isBlank()) null else value } catch (_: Exception) { null }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onBackPressed() { if (web != null) { showHome() } else super.onBackPressed() }
}
