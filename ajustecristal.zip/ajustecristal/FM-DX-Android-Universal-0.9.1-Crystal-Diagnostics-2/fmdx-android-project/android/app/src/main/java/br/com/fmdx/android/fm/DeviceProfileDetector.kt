package br.com.fmdx.android.fm

import android.os.Build

/** Perfil baseado em evidências públicas do próprio aparelho. Não infere chipset apenas pela marca. */
data class DeviceProfile(
    val platform: String,
    val backendId: String,
    val confidence: String,
    val evidence: List<String>,
    val manufacturer: String,
    val model: String,
    val hardware: String,
    val board: String,
    val device: String,
    val product: String,
    val socManufacturer: String,
    val socModel: String
) {
    fun summary(): String = "$platform ($confidence)"
}

object DeviceProfileDetector {
    fun detect(): DeviceProfile {
        val manufacturer = Build.MANUFACTURER.orEmpty()
        val model = Build.MODEL.orEmpty()
        val hardware = Build.HARDWARE.orEmpty()
        val board = Build.BOARD.orEmpty()
        val device = Build.DEVICE.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val socManufacturer = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER.orEmpty() else ""
        val socModel = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL.orEmpty() else ""
        val values = listOf(manufacturer, Build.BRAND.orEmpty(), hardware, board, device, product, socManufacturer, socModel)
        val text = values.joinToString(" ").lowercase()
        fun hits(vararg keys: String) = keys.filter { text.contains(it) }

        val q = hits("qualcomm", "qcom", "snapdragon", "sdm", "sm6", "sm7", "sm8")
        val m = hits("mediatek", "mt67", "mt68", "mt69", "dimensity", "helio")
        val e = hits("exynos", "s5e")
        val (platform, backend, found) = when {
            q.isNotEmpty() -> Triple("Qualcomm/Snapdragon", "qualcomm", q)
            m.isNotEmpty() -> Triple("MediaTek", "mediatek", m)
            e.isNotEmpty() -> Triple("Samsung Exynos", "samsung_exynos", e)
            else -> Triple("Desconhecida", "unsupported", emptyList())
        }
        val evidence = if (found.isEmpty()) listOf("Nenhuma assinatura pública confiável de plataforma encontrada")
        else found.distinct().map { "Evidência pública: $it" }

        return DeviceProfile(platform, backend, confidence(found), evidence, manufacturer, model, hardware, board, device, product, socManufacturer, socModel)
    }

    private fun confidence(hits: List<String>) = when {
        hits.size >= 2 -> "alta"
        hits.size == 1 -> "média"
        else -> "baixa"
    }
}
