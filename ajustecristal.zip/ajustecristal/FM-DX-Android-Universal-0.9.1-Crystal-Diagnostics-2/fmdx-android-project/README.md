# FM-DX Android — projeto inicial

Projeto híbrido (interface original preservada + melhorias Android), com diretório público e acesso privado por endereço/convite.

## O que está pronto nesta base
- Aplicativo Android nativo (Kotlin) que guarda endereços e abre o FM-DX Webserver no WebView.
- Campo para adicionar servidor por URL, lista de servidores públicos via API e abertura de servidor privado por endereço compartilhado.
- Serviço de diretório Node.js simples: cadastro autenticado de servidores, listagem pública, consulta por ID e remoção autenticada.
- Código original do FM-DX Webserver incluído em `fm-dx-webserver/`, preservando o Exclusive Tuner existente.

## Limites desta primeira versão
- O APK é cliente/controle e player web; não executa o receptor físico nem o servidor Node.js dentro do Android.
- O diretório precisa ser publicado em um servidor HTTPS para descoberta mundial. O endereço padrão no app é um placeholder e deve ser configurado antes do uso público.
- O cadastro do diretório é manual via API; ainda não há cadastro automático no servidor FM-DX, contas de usuário, moderação ou verificação contínua de disponibilidade.
- O app foi entregue como projeto-fonte Android Studio. A compilação final requer Android SDK/Gradle e teste em aparelho real.

## Abrir no Android Studio
1. Abra a pasta `android/` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Edite `DIRECTORY_API` em `MainActivity.kt` para o endereço HTTPS do serviço de diretório.
4. Execute em um Android 8.0 ou superior.

## Executar o FM-DX Webserver
Consulte `fm-dx-webserver/README.md` e as instruções oficiais para o receptor compatível. Em geral, instale Node.js, execute `npm install` e depois `npm run webserver`.

## Executar o diretório
```bash
cd directory-service
npm install
DIRECTORY_ADMIN_TOKEN='troque-por-um-segredo-longo' PORT=8787 npm start
```
Coloque-o atrás de HTTPS (proxy reverso) antes de expor à internet.

### API do diretório
- `GET /api/servers` — lista servidores públicos.
- `GET /api/servers/:id` — detalhes de um servidor público.
- `POST /api/servers` — registra/atualiza servidor; exige `Authorization: Bearer <DIRECTORY_ADMIN_TOKEN>`.
- `DELETE /api/servers/:id` — remove servidor; exige token.

Exemplo de cadastro:
```bash
curl -X POST https://SEU-DIRETORIO/api/servers \
  -H 'Authorization: Bearer SEU_TOKEN' -H 'Content-Type: application/json' \
  -d '{"name":"Minha estação FM-DX","url":"https://radio.exemplo.com","country":"Brasil","city":"Jauru","description":"Receptor FM-DX"}'
```
Para servidor privado, não o cadastre no diretório público: compartilhe diretamente o endereço com as pessoas autorizadas. Configure autenticação e HTTPS no próprio FM-DX.

## Próximas etapas recomendadas
1. Compilar e testar o APK com um servidor FM-DX real.
2. Validar áudio, WebSocket, login e permissões no WebView.
3. Integrar cadastro opcional do servidor ao diretório.
4. Adicionar favoritos, histórico, filtros por país e estado e indicador online/offline.
5. Publicar o diretório com proteção contra abuso, moderação e política de privacidade.

## Licenças
O FM-DX Webserver incluído mantém seus arquivos e licença originais. Consulte `fm-dx-webserver/LICENSE` e os avisos de cada dependência. O código novo deste protótipo é fornecido como ponto de partida; revise as obrigações de distribuição antes de publicar APKs modificados.

## Atualização 0.2.0
- A URL do diretório agora pode ser configurada diretamente no aplicativo e fica salva no aparelho.
- Removido o bloqueio causado pelo endereço fictício `SEU-DIRETORIO.example`.
- Adicionadas configurações de Java/Kotlin 17 e BuildConfig para compatibilidade com Android Gradle Plugin 8.7.
- Para compilar, abra `android/` no Android Studio e use JDK 17.

## FM hardware layer (0.4.0)
A versão 0.4.0 inclui uma abstração `FmRadioController` e um `FmHardwareManager`.
Por padrão, nenhum fabricante é marcado como suportado sem uma API/driver realmente disponível. Isso evita que o aplicativo finja controlar o rádio FM quando o Android não expõe acesso público ao tuner.


## Versão 0.5.0 — detecção de receptores USB

Esta versão adiciona enumeração de dispositivos USB conectados por meio de `UsbManager` e exibe VID/PID e quantidade de interfaces na tela **Meu Receptor FM**. A detecção é apenas inventário: não declara um dispositivo como tuner FM/SDR nem inicia captura de áudio. Cada receptor exige identificação do chipset, protocolo, driver e permissões USB apropriados.

Os adaptadores internos Samsung/Qualcomm/MediaTek continuam como detectores de plataforma, sem controle real de sintonia. A API pública universal de tuner FM não existe no Android. Streaming ainda depende de uma fonte de áudio real validada e não é ativado por esta versão.


## Compilação automática (sem Android Studio)

O projeto inclui `.github/workflows/android-apk.yml`. Quando a pasta do projeto for enviada para um repositório GitHub e o workflow for executado, o GitHub Actions compila o APK de debug automaticamente e disponibiliza o arquivo como artefato `FM-DX-Android-APK`.

Nesta versão, o diagnóstico Samsung/Exynos é somente de leitura e não declara controle real do tuner sem uma API pública ou integração validada.


## 0.7.0 Universal
Adicionado diagnóstico universal por fabricante/plataforma (Samsung/Exynos, Qualcomm, MediaTek e genérico). Os perfis não afirmam controle real do tuner; o app só reporta evidências públicas acessíveis.

## Versão 0.8.0 Universal
- Corrige a identificação: fabricante não é tratado como chipset.
- Cria perfil de plataforma com evidências e nível de confiança.
- Seleciona o backend apenas por assinatura pública de plataforma.
- Mantém explícita a diferença entre plataforma detectada e controle real do tuner.
- Atualiza a versão Android para 0.8.0 (versionCode 6).
