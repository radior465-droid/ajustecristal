package br.com.fmdx.android.fm
class SamsungFmController : PlatformFmController("Samsung Exynos — diagnóstico")
