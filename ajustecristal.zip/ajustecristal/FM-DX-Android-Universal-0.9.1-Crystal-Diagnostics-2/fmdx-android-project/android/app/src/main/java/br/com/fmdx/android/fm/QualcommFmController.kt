package br.com.fmdx.android.fm
class QualcommFmController : PlatformFmController("Qualcomm/Snapdragon — diagnóstico")
