package br.com.fmdx.android.fm

/**
 * Abstração comum para diferentes implementações de rádio FM.
 * O Android não oferece uma API pública universal de tuner FM; cada adapter
 * só deve declarar suporte quando uma integração realmente estiver disponível.
 */
interface FmRadioController {
    val backendName: String
    fun isSupported(): Boolean
    fun start(): Boolean
    fun stop()
    fun tune(frequencyKhz: Int): Boolean
    fun getFrequency(): Int?
    fun seekUp(): Int?
    fun seekDown(): Int?
}
