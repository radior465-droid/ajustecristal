package br.com.fmdx.android.fm

/** Base segura para adapters específicos.
 * Nesta versão um adapter não controla hardware até existir uma API/driver público confirmado.
 */
abstract class PlatformFmController(
    override val backendName: String
) : FmRadioController {
    protected var frequency: Int? = null
    override fun isSupported(): Boolean = false
    override fun start(): Boolean = false
    override fun stop() { frequency = null }
    override fun tune(frequencyKhz: Int): Boolean = false
    override fun getFrequency(): Int? = frequency
    override fun seekUp(): Int? = null
    override fun seekDown(): Int? = null
}
