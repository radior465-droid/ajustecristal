package br.com.fmdx.android.fm

import android.content.Context
import android.os.Build

/** Seleciona somente pelo perfil de chipset; fabricante sozinho não libera um backend. */
class FmHardwareManager(private val context: Context) {
    private val usbDiscovery = UsbReceiverDiscovery(context.applicationContext)
    private val samsungDiagnostics by lazy { SamsungExynosDiagnostics(context.applicationContext) }
    private val universalDiagnostics by lazy { UniversalFmDiagnostics(context.applicationContext) }
    private val profile by lazy { DeviceProfileDetector.detect() }
    private val controller: FmRadioController by lazy {
        when (profile.backendId) {
            "qualcomm" -> QualcommFmController()
            "mediatek" -> MediaTekFmController()
            "samsung_exynos" -> SamsungFmController()
            else -> UnsupportedFmController()
        }
    }

    fun controller(): FmRadioController = controller
    fun samsungDiagnosticReport(): String = samsungDiagnostics.run().asText()
    fun universalDiagnosticReport(): String = universalDiagnostics.run().asText()

    fun report(): String = buildString {
        append("FM-DX Android — Compatibilidade 0.9.0\n\n")
        append("Fabricante: ${Build.MANUFACTURER.ifBlank { "Desconhecido" }}\n")
        append("Modelo: ${Build.MODEL.ifBlank { "Desconhecido" }}\n")
        append("Hardware: ${Build.HARDWARE}\nBoard: ${Build.BOARD}\nSoC fabricante: ${profile.socManufacturer.ifBlank { "não informado" }}\nSoC modelo: ${profile.socModel.ifBlank { "não informado" }}\nAndroid: ${Build.VERSION.RELEASE}\n\n")
        append("PLATAFORMA DETECTADA\n")
        append("${profile.summary()}\n")
        profile.evidence.forEach { append("• $it\n") }
        append("\nBACKEND\n")
        append("Selecionado: ${controller.backendName}\nModo: diagnóstico seguro\n")
        append(if (controller.isSupported()) "Controle real do tuner: disponível" else "Controle real do tuner: ainda não validado para este aparelho")
        append("\n\nRECEPTORES USB\n")
        val devices = usbDiscovery.describeAttachedDevices()
        if (devices.isEmpty()) append("Nenhum dispositivo USB detectado.") else devices.forEach { append("• $it\n") }
        append("\nA detecção USB não confirma compatibilidade FM/SDR: é necessário protocolo e driver acessíveis ao Android.")
    }
}
