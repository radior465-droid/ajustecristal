package br.com.fmdx.android.fm

import android.os.Build
import java.io.File

/**
 * Investigação somente de leitura. Lista nomes de interfaces visíveis ao app;
 * nunca abre /dev nodes, não lê/escreve registradores e não altera sysfs.
 */
class CrystalInterfaceDiagnostics {
    data class Result(val lines: List<String>) {
        fun asText(): String = lines.joinToString("\n")
    }

    fun run(): Result {
        val lines = mutableListOf<String>()
        lines += "FM-DX — Diagnóstico de interface do oscilador/cristal"
        lines += ""
        lines += "DISPOSITIVO"
        lines += "Fabricante: ${Build.MANUFACTURER}"
        lines += "Modelo: ${Build.MODEL}"
        lines += "Hardware: ${Build.HARDWARE}"
        if (Build.VERSION.SDK_INT >= 31) {
            lines += "SoC: ${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"
        }
        lines += ""
        lines += "VERIFICAÇÃO DE INTERFACES VISÍVEIS"
        val roots = listOf("/sys/class/misc", "/sys/bus/platform/devices", "/dev")
        val matches = mutableListOf<String>()
        for (root in roots) {
            val dir = File(root)
            if (!dir.isDirectory || !dir.canRead()) {
                lines += "$root: indisponível para leitura pelo aplicativo"
                continue
            }
            val names = try { dir.list()?.toList().orEmpty() } catch (_: SecurityException) { emptyList() }
            val found = names.filter {
                val n = it.lowercase()
                n.contains("fm") || n.contains("radio") || n.contains("tuner") ||
                    n.contains("rds") || n.contains("clock") || n.contains("clk")
            }.sorted()
            if (found.isEmpty()) {
                lines += "$root: nenhum nome relacionado a FM/tuner/clock visível"
            } else {
                found.take(30).forEach { matches += "$root/$it" }
                lines += "$root: ${found.size} possível(is) nome(s) relacionado(s)"
            }
        }
        if (matches.isNotEmpty()) {
            lines += ""
            lines += "NOMES ENCONTRADOS (apenas nomes, sem abrir os arquivos)"
            lines += matches.take(60).map { "• $it" }
        }
        lines += ""
        lines += "ACESSO AO CRISTAL"
        lines += "Acesso direto ao cristal/oscilador: não demonstrado."
        lines += "Controle de registradores do tuner: não tentado."
        lines += "Este teste não abre dispositivos, não escreve em /sys e não altera frequências."
        lines += "Um nome encontrado não prova que seja o tuner FM nem que permita controle."
        lines += ""
        lines += "PRÓXIMO PASSO"
        lines += "Compare este relatório com o modelo/firmware e procure uma API ou driver documentado e acessível."
        return Result(lines)
    }
}
